
<?php
/**
 * @package Cat Typing
 * @version 1.0.0
 */
/*
Plugin Name: Cat Typing
Plugin URI: https://github.com/kmcleod1234
Description: Adds a picture of a cat to the top of every Post that is tagged "cat", and adds the date of publication to the beginning of the Title of the Post.
Author: Ken McLeod
Version: 1.0.0
Author URI: https://github.com/kmcleod1234
*/
echo "Today is " . date("m/d/Y") "- Cat Typing";
echo "typing-cat-gif.gif" width="480" height="480"/>;